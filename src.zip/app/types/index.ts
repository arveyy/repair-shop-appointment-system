export type RepairStatus = 'Pending' | 'In Progress' | 'Testing' | 'Ready for Pickup' | 'Completed' | 'Cancelled';

export type DeviceType = 'Smartphone' | 'Laptop' | 'Tablet' | 'Console' | 'Other';

export interface Branch {
  id: string;
  name: string;
  location: string;
  isOpen: boolean;
  currentQueueCount: number;
  estimatedWaitMinutes: number;
}

export interface RepairJob {
  id: string;
  ticketNumber: string;
  customerName: string;
  contactNumber: string;
  branchId: string;
  deviceType: DeviceType;
  deviceModel: string;
  issueDescription: string;
  status: RepairStatus;
  createdAt: string;
  scheduledTime?: string;
  estimatedCompletion?: string;
  technicianName?: string;
}

export interface BranchStats {
  branchId: string;
  totalRepairs: number;
  avgCompletionTime: number; // in hours
  customerSatisfaction: number; // 1-5
}

import React, { useState, useMemo } from 'react';
import { Sidebar } from './components/Sidebar';
import { QueueManager } from './components/QueueManager';
import { BookingFlow } from './components/BookingFlow';
import { QueueTracker } from './components/QueueTracker';
import { MOCK_BRANCHES, MOCK_REPAIRS } from './data/mock';
import { RepairJob, RepairStatus, Branch } from './types';
import { Toaster, toast } from 'sonner';
import { 
  Monitor, 
  Smartphone, 
  Wrench, 
  Clock, 
  ShieldCheck, 
  MapPin,
  BarChart3,
  Users,
  LayoutDashboard,
  Settings,
  Menu,
  X,
  Plus,
  Search
} from 'lucide-react';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  BarChart,
  Bar,
  Cell
} from 'recharts';

// --- Analytics Component ---
const AnalyticsDashboard = ({ repairs }: { repairs: RepairJob[] }) => {
  const data = [
    { name: 'Mon', repairs: 12 },
    { name: 'Tue', repairs: 19 },
    { name: 'Wed', repairs: 15 },
    { name: 'Thu', repairs: 22 },
    { name: 'Fri', repairs: 30 },
    { name: 'Sat', repairs: 25 },
    { name: 'Sun', repairs: 10 },
  ];

  const statusData = [
    { name: 'Completed', value: 45, color: '#10b981' },
    { name: 'In Progress', value: 12, color: '#3b82f6' },
    { name: 'Pending', value: 8, color: '#f59e0b' },
  ];

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-slate-900 tracking-tight">Performance Analytics</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {[
          { label: 'Total Repairs', value: '1,284', change: '+12%', icon: Wrench },
          { label: 'Avg Wait Time', value: '42 min', change: '-5%', icon: Clock },
          { label: 'Customer Satisfaction', value: '4.8/5', change: '+0.2', icon: ShieldCheck },
        ].map((stat, i) => (
          <div key={i} className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
            <div className="flex justify-between items-start mb-4">
              <div className="p-2 bg-blue-50 text-blue-600 rounded-lg">
                <stat.icon className="w-5 h-5" />
              </div>
              <span className={`text-xs font-bold px-2 py-1 rounded-full ${
                stat.change.startsWith('+') ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
              }`}>
                {stat.change}
              </span>
            </div>
            <p className="text-sm font-medium text-slate-500">{stat.label}</p>
            <p className="text-2xl font-bold text-slate-900">{stat.value}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
          <h3 className="text-sm font-bold text-slate-900 mb-6 uppercase tracking-wider">Weekly Repair Volume</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={data}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#64748b' }} />
                <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#64748b' }} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#1e293b', border: 'none', borderRadius: '8px', color: '#fff' }}
                  itemStyle={{ color: '#fff' }}
                />
                <Line type="monotone" dataKey="repairs" stroke="#3b82f6" strokeWidth={3} dot={{ fill: '#3b82f6', r: 4 }} activeDot={{ r: 6 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
          <h3 className="text-sm font-bold text-slate-900 mb-6 uppercase tracking-wider">Current Status Distribution</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={statusData} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f1f5f9" />
                <XAxis type="number" hide />
                <YAxis dataKey="name" type="category" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#64748b' }} width={100} />
                <Tooltip cursor={{ fill: '#f8fafc' }} />
                <Bar dataKey="value" radius={[0, 4, 4, 0]}>
                  {statusData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};

export default function App() {
  const [view, setView] = useState<'customer' | 'admin'>('customer');
  const [activeTab, setActiveTab] = useState('dashboard');
  const [repairs, setRepairs] = useState<RepairJob[]>(MOCK_REPAIRS);
  const [branches] = useState<Branch[]>(MOCK_BRANCHES);
  const [trackingTicket, setTrackingTicket] = useState<string | null>(null);
  const [showBooking, setShowBooking] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // Filtered repair for tracker
  const trackedRepair = useMemo(() => {
    if (!trackingTicket) return undefined;
    return repairs.find(r => r.ticketNumber.toUpperCase() === trackingTicket.toUpperCase());
  }, [trackingTicket, repairs]);

  const handleUpdateStatus = (id: string, status: RepairStatus) => {
    setRepairs(prev => prev.map(r => r.id === id ? { ...r, status } : r));
    toast.success(`Ticket status updated to ${status}`);
  };

  const handleAddRepair = (data: any) => {
    const newRepair: RepairJob = {
      id: Math.random().toString(36).substr(2, 9),
      ticketNumber: `QT-${1000 + repairs.length + 1}`,
      customerName: data.customerName,
      contactNumber: data.contactNumber,
      branchId: data.branchId,
      deviceType: data.deviceType,
      deviceModel: data.deviceModel,
      issueDescription: data.issueDescription,
      status: 'Pending',
      createdAt: new Date().toISOString(),
    };
    setRepairs([newRepair, ...repairs]);
    setShowBooking(false);
    setTrackingTicket(newRepair.ticketNumber);
    toast.success('Your repair has been queued!', {
      description: `Ticket Number: ${newRepair.ticketNumber}`
    });
  };

  // Admin Dashboard Content
  const renderAdminContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold text-slate-900 tracking-tight">Welcome back, Admin</h2>
                <p className="text-slate-500 text-sm">Here's what's happening at Lahug Branch today.</p>
              </div>
              <div className="flex items-center gap-4">
                <div className="text-right hidden sm:block">
                  <p className="text-xs font-bold text-slate-400 uppercase">Current Load</p>
                  <p className="text-sm font-bold text-blue-600">Moderate (85%)</p>
                </div>
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
               {[
                 { label: 'Pending', val: repairs.filter(r => r.status === 'Pending').length, color: 'bg-amber-500' },
                 { label: 'In Progress', val: repairs.filter(r => r.status === 'In Progress').length, color: 'bg-blue-500' },
                 { label: 'Ready for Pickup', val: repairs.filter(r => r.status === 'Ready for Pickup').length, color: 'bg-green-500' },
                 { label: 'Total Today', val: 14, color: 'bg-slate-700' },
               ].map((stat, i) => (
                 <div key={i} className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex items-center gap-4">
                   <div className={`w-2 h-12 rounded-full ${stat.color}`} />
                   <div>
                     <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">{stat.label}</p>
                     <p className="text-2xl font-bold text-slate-900">{stat.val}</p>
                   </div>
                 </div>
               ))}
            </div>
            <QueueManager 
              repairs={repairs.slice(0, 5)} 
              onUpdateStatus={handleUpdateStatus} 
              onAddRepair={() => setActiveTab('queue')}
            />
          </div>
        );
      case 'queue':
        return <QueueManager repairs={repairs} onUpdateStatus={handleUpdateStatus} onAddRepair={() => toast.info('Walk-in modal would open here')} />;
      case 'analytics':
        return <AnalyticsDashboard repairs={repairs} />;
      default:
        return (
          <div className="flex flex-col items-center justify-center py-20 text-slate-400">
            <LayoutDashboard className="w-16 h-16 mb-4 opacity-20" />
            <p className="font-medium">This module is coming soon.</p>
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-900">
      <Toaster position="top-center" richColors />
      
      {/* Switcher for Demo */}
      <div className="fixed bottom-6 right-6 z-50 flex gap-2">
        <button 
          onClick={() => setView(view === 'customer' ? 'admin' : 'customer')}
          className="bg-slate-900 text-white px-4 py-2 rounded-full shadow-2xl font-bold text-xs flex items-center gap-2 border border-slate-700 hover:bg-black transition-all"
        >
          {view === 'customer' ? <LayoutDashboard className="w-4 h-4" /> : <Users className="w-4 h-4" />}
          Switch to {view === 'customer' ? 'Admin View' : 'Customer View'}
        </button>
      </div>

      {view === 'admin' ? (
        <div className="flex">
          <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} branchName="Lahug Branch" />
          <main className="flex-1 ml-64 p-8 max-w-7xl mx-auto w-full">
            {renderAdminContent()}
          </main>
        </div>
      ) : (
        <div className="pb-20">
          {/* Customer Header */}
          <header className="bg-white border-b border-slate-100 sticky top-0 z-30">
            <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
              <div className="flex items-center gap-2 text-blue-600 font-black text-xl tracking-tight">
                <Wrench className="w-6 h-6" />
                <span>QueueTech</span>
              </div>
              <nav className="hidden md:flex items-center gap-8">
                <button onClick={() => { setShowBooking(false); setTrackingTicket(null); }} className="text-sm font-bold text-slate-600 hover:text-blue-600 transition-colors">Home</button>
                <button onClick={() => { setShowBooking(false); setTrackingTicket(null); }} className="text-sm font-bold text-slate-600 hover:text-blue-600 transition-colors">Branches</button>
                <button onClick={() => { setShowBooking(false); setTrackingTicket(''); }} className="text-sm font-bold text-slate-600 hover:text-blue-600 transition-colors">Track Status</button>
                <button 
                  onClick={() => setShowBooking(true)}
                  className="bg-blue-600 text-white px-5 py-2 rounded-lg font-bold text-sm shadow-lg shadow-blue-900/10 hover:bg-blue-700 transition-all"
                >
                  Book Repair
                </button>
              </nav>
              <button className="md:hidden p-2 text-slate-600" onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}>
                {isMobileMenuOpen ? <X /> : <Menu />}
              </button>
            </div>
          </header>

          {/* Customer Main Content */}
          <main className="pt-8 px-4">
            {showBooking ? (
              <BookingFlow branches={branches} onComplete={handleAddRepair} />
            ) : trackingTicket !== null ? (
              <QueueTracker repair={trackedRepair} onSearch={setTrackingTicket} />
            ) : (
              <div className="max-w-7xl mx-auto">
                {/* Hero Section */}
                <div className="text-center py-12 md:py-24 space-y-6">
                  <div className="inline-flex items-center gap-2 bg-blue-50 text-blue-700 px-4 py-1.5 rounded-full text-xs font-bold border border-blue-100">
                    <span className="relative flex h-2 w-2">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-2 w-2 bg-blue-500"></span>
                    </span>
                    Real-time queue management for Cebu repair shops
                  </div>
                  <h1 className="text-4xl md:text-6xl font-black text-slate-900 tracking-tight leading-tight">
                    Expert Repairs. <br />
                    <span className="text-blue-600">Zero Wait Time.</span>
                  </h1>
                  <p className="max-w-2xl mx-auto text-lg text-slate-600">
                    Digitizing device repairs in Cebu City. Skip the manual chats and track your repair status in real-time from anywhere.
                  </p>
                  <div className="flex flex-col sm:flex-row gap-4 justify-center pt-4">
                    <button 
                      onClick={() => setShowBooking(true)}
                      className="bg-blue-600 text-white px-8 py-4 rounded-xl font-bold text-lg shadow-xl shadow-blue-900/20 hover:bg-blue-700 transition-all flex items-center justify-center gap-2"
                    >
                      <Plus className="w-5 h-5" />
                      Book a Repair Slot
                    </button>
                    <button 
                      onClick={() => setTrackingTicket('')}
                      className="bg-white text-slate-900 border-2 border-slate-200 px-8 py-4 rounded-xl font-bold text-lg hover:border-blue-600 hover:text-blue-600 transition-all flex items-center justify-center gap-2"
                    >
                      <Search className="w-5 h-5" />
                      Track My Status
                    </button>
                  </div>
                </div>

                {/* Features */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8 py-16 border-t border-slate-100">
                  <div className="space-y-4">
                    <div className="w-12 h-12 bg-indigo-50 text-indigo-600 rounded-xl flex items-center justify-center">
                      <MapPin className="w-6 h-6" />
                    </div>
                    <h3 className="text-xl font-bold">Multi-Branch Support</h3>
                    <p className="text-slate-500 text-sm leading-relaxed">Choose from our locations across Cebu City including Lahug, IT Park, and Mandaue.</p>
                  </div>
                  <div className="space-y-4">
                    <div className="w-12 h-12 bg-amber-50 text-amber-600 rounded-xl flex items-center justify-center">
                      <Clock className="w-6 h-6" />
                    </div>
                    <h3 className="text-xl font-bold">FIFO Queue System</h3>
                    <p className="text-slate-500 text-sm leading-relaxed">Our systematic scheduling algorithm ensures fair service for everyone based on arrival time.</p>
                  </div>
                  <div className="space-y-4">
                    <div className="w-12 h-12 bg-emerald-50 text-emerald-600 rounded-xl flex items-center justify-center">
                      <Smartphone className="w-6 h-6" />
                    </div>
                    <h3 className="text-xl font-bold">Real-time Updates</h3>
                    <p className="text-slate-500 text-sm leading-relaxed">Receive instant notifications as your device moves from diagnostics to completion.</p>
                  </div>
                </div>

                {/* Branch Cards */}
                <div className="py-16">
                  <h2 className="text-3xl font-black mb-8">Our Branches</h2>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                    {branches.map(branch => (
                      <div key={branch.id} className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition-all group">
                        <div className="flex justify-between items-start mb-4">
                          <div className={`px-2 py-1 rounded text-[10px] font-bold uppercase ${branch.isOpen ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                            {branch.isOpen ? 'Open Now' : 'Closed'}
                          </div>
                          <div className="p-2 bg-slate-50 rounded-lg group-hover:bg-blue-50 transition-colors">
                            <MapPin className="w-4 h-4 text-slate-400 group-hover:text-blue-600" />
                          </div>
                        </div>
                        <h4 className="font-bold text-slate-900 mb-1">{branch.name}</h4>
                        <p className="text-xs text-slate-500 mb-4">{branch.location}</p>
                        <div className="flex items-center justify-between pt-4 border-t border-slate-50">
                          <div className="text-center">
                            <p className="text-[10px] font-bold text-slate-400 uppercase">Wait Time</p>
                            <p className="text-sm font-bold text-slate-900">{branch.estimatedWaitMinutes}m</p>
                          </div>
                          <div className="text-center">
                            <p className="text-[10px] font-bold text-slate-400 uppercase">Queue</p>
                            <p className="text-sm font-bold text-slate-900">{branch.currentQueueCount}</p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </main>
        </div>
      )}
    </div>
  );
}

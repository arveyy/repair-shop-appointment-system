import React from 'react';
import { 
  CheckCircle2, 
  Clock, 
  Search, 
  RefreshCcw, 
  PhoneCall, 
  Wrench,
  Smartphone,
  Laptop,
  Monitor,
  Gamepad2,
  AlertCircle
} from 'lucide-react';
import { RepairJob, RepairStatus } from '../types';
import { motion } from 'motion/react';

interface QueueTrackerProps {
  repair?: RepairJob;
  onSearch: (ticket: string) => void;
}

export const QueueTracker: React.FC<QueueTrackerProps> = ({ repair, onSearch }) => {
  const [ticketInput, setTicketInput] = React.useState('');

  const steps: RepairStatus[] = ['Pending', 'In Progress', 'Testing', 'Ready for Pickup', 'Completed'];
  
  const getCurrentStepIndex = (status: RepairStatus) => {
    return steps.indexOf(status);
  };

  const getDeviceIcon = (type: string) => {
    switch (type) {
      case 'Smartphone': return Smartphone;
      case 'Laptop': return Laptop;
      case 'Tablet': return Monitor;
      case 'Console': return Gamepad2;
      default: return Wrench;
    }
  };

  const DeviceIcon = repair ? getDeviceIcon(repair.deviceType) : null;

  return (
    <div className="max-w-xl mx-auto w-full px-4 py-8">
      {!repair ? (
        <div className="bg-white p-8 rounded-2xl shadow-xl border border-slate-100 text-center">
          <div className="w-16 h-16 bg-blue-50 rounded-full flex items-center justify-center text-blue-600 mx-auto mb-6">
            <Search className="w-8 h-8" />
          </div>
          <h2 className="text-2xl font-bold text-slate-900 mb-2">Track Your Repair</h2>
          <p className="text-slate-500 mb-8">Enter your ticket number to see your status in the queue.</p>
          
          <div className="flex gap-2">
            <input 
              type="text" 
              value={ticketInput}
              onChange={(e) => setTicketInput(e.target.value)}
              placeholder="e.g. QT-1001"
              className="flex-1 px-4 py-3 rounded-lg border border-slate-200 focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none uppercase font-mono font-bold"
            />
            <button 
              onClick={() => onSearch(ticketInput)}
              className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg font-bold transition-all"
            >
              Search
            </button>
          </div>
          
          <div className="mt-8 pt-8 border-t border-slate-100 grid grid-cols-2 gap-4">
            <div className="text-left">
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Cebu IT Park</p>
              <p className="text-sm font-bold text-slate-700">7 in Queue</p>
            </div>
            <div className="text-left">
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Lahug Branch</p>
              <p className="text-sm font-bold text-slate-700">4 in Queue</p>
            </div>
          </div>
        </div>
      ) : (
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="space-y-6"
        >
          <div className="bg-white p-6 rounded-2xl shadow-xl border border-blue-100">
            <div className="flex justify-between items-start mb-6">
              <div>
                <span className="text-xs font-bold text-blue-600 uppercase tracking-widest">Repair Ticket</span>
                <h2 className="text-2xl font-bold text-slate-900 font-mono">{repair.ticketNumber}</h2>
              </div>
              <button 
                onClick={() => onSearch(repair.ticketNumber)}
                className="p-2 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-full transition-all"
              >
                <RefreshCcw className="w-5 h-5" />
              </button>
            </div>

            <div className="flex gap-4 p-4 bg-slate-50 rounded-xl mb-8">
              <div className="w-12 h-12 bg-white rounded-lg flex items-center justify-center text-slate-600 shadow-sm">
                {DeviceIcon && <DeviceIcon className="w-6 h-6" />}
              </div>
              <div>
                <p className="text-sm font-bold text-slate-900">{repair.deviceModel}</p>
                <p className="text-xs text-slate-500">{repair.issueDescription}</p>
              </div>
            </div>

            <div className="relative">
              <div className="absolute left-[15px] top-0 bottom-0 w-0.5 bg-slate-100" />
              
              <div className="space-y-8 relative">
                {steps.map((status, index) => {
                  const isActive = getCurrentStepIndex(repair.status) >= index;
                  const isCurrent = repair.status === status;
                  
                  return (
                    <div key={status} className="flex gap-4">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center z-10 ${
                        isActive ? 'bg-blue-600 text-white' : 'bg-slate-200 text-slate-400'
                      }`}>
                        {isActive && !isCurrent ? <CheckCircle2 className="w-5 h-5" /> : (index + 1)}
                      </div>
                      <div className="pt-1">
                        <p className={`text-sm font-bold ${isActive ? 'text-slate-900' : 'text-slate-400'}`}>
                          {status}
                        </p>
                        {isCurrent && (
                          <motion.p 
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            className="text-xs text-blue-600 font-medium mt-0.5"
                          >
                            Currently here • {repair.status === 'Pending' ? 'Waiting in Queue' : 'In Progress'}
                          </motion.p>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          <div className="bg-slate-900 text-white p-6 rounded-2xl shadow-xl flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-slate-800 rounded-full flex items-center justify-center">
                <PhoneCall className="w-5 h-5 text-blue-400" />
              </div>
              <div>
                <p className="text-xs text-slate-400">Need help?</p>
                <p className="text-sm font-bold">Contact Lahug Branch</p>
              </div>
            </div>
            <a href="tel:09171234567" className="bg-blue-600 px-4 py-2 rounded-lg text-sm font-bold">Call Now</a>
          </div>

          <button 
            onClick={() => onSearch('')}
            className="w-full text-center text-sm font-medium text-slate-500 hover:text-blue-600 transition-colors"
          >
            Track another device
          </button>
        </motion.div>
      )}
    </div>
  );
};

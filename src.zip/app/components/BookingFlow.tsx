import React, { useState } from 'react';
import { 
  MapPin, 
  Clock, 
  ChevronRight, 
  Users, 
  CheckCircle2, 
  Smartphone,
  Laptop,
  Monitor,
  Gamepad2,
  ChevronLeft
} from 'lucide-react';
import { Branch, DeviceType } from '../types';
import { motion, AnimatePresence } from 'motion/react';

interface BookingFlowProps {
  branches: Branch[];
  onComplete: (data: any) => void;
}

export const BookingFlow: React.FC<BookingFlowProps> = ({ branches, onComplete }) => {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    branchId: '',
    customerName: '',
    contactNumber: '',
    deviceType: 'Smartphone' as DeviceType,
    deviceModel: '',
    issueDescription: ''
  });

  const deviceTypes: { type: DeviceType, icon: any }[] = [
    { type: 'Smartphone', icon: Smartphone },
    { type: 'Laptop', icon: Laptop },
    { type: 'Tablet', icon: Monitor },
    { type: 'Console', icon: Gamepad2 },
    { type: 'Other', icon: ChevronRight },
  ];

  const handleNext = () => setStep(step + 1);
  const handleBack = () => setStep(step - 1);

  return (
    <div className="max-w-2xl mx-auto w-full">
      <div className="mb-8 flex justify-between items-center px-4">
        {[1, 2, 3].map((s) => (
          <div key={s} className="flex items-center gap-2">
            <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm ${
              step >= s ? 'bg-blue-600 text-white' : 'bg-slate-200 text-slate-500'
            }`}>
              {step > s ? <CheckCircle2 className="w-5 h-5" /> : s}
            </div>
            {s < 3 && <div className={`w-12 h-1 bg-slate-200 ${step > s ? 'bg-blue-600' : ''}`} />}
          </div>
        ))}
      </div>

      <AnimatePresence mode="wait">
        {step === 1 && (
          <motion.div 
            key="step1"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="space-y-4"
          >
            <h2 className="text-xl font-bold px-4">Select a Branch near you</h2>
            <div className="grid gap-4 px-4">
              {branches.map((branch) => (
                <button
                  key={branch.id}
                  onClick={() => {
                    setFormData({ ...formData, branchId: branch.id });
                    handleNext();
                  }}
                  disabled={!branch.isOpen}
                  className={`w-full p-4 rounded-xl border-2 text-left transition-all ${
                    !branch.isOpen 
                      ? 'bg-slate-50 border-slate-100 opacity-60 cursor-not-allowed' 
                      : 'bg-white border-slate-200 hover:border-blue-500 hover:shadow-md'
                  }`}
                >
                  <div className="flex justify-between items-start">
                    <div className="flex gap-3">
                      <div className="w-10 h-10 bg-blue-50 rounded-lg flex items-center justify-center text-blue-600">
                        <MapPin className="w-5 h-5" />
                      </div>
                      <div>
                        <h3 className="font-bold text-slate-900">{branch.name}</h3>
                        <p className="text-sm text-slate-500">{branch.location}</p>
                      </div>
                    </div>
                    {!branch.isOpen && (
                      <span className="text-[10px] font-bold uppercase bg-slate-200 text-slate-600 px-2 py-1 rounded">Closed</span>
                    )}
                  </div>
                  <div className="mt-4 pt-4 border-t border-slate-100 flex gap-6 text-sm">
                    <div className="flex items-center gap-1.5 text-slate-600">
                      <Users className="w-4 h-4" />
                      <span>{branch.currentQueueCount} in queue</span>
                    </div>
                    <div className="flex items-center gap-1.5 text-slate-600">
                      <Clock className="w-4 h-4" />
                      <span>~{branch.estimatedWaitMinutes} mins wait</span>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </motion.div>
        )}

        {step === 2 && (
          <motion.div 
            key="step2"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="px-4 space-y-6"
          >
            <div className="flex items-center gap-2 mb-2">
              <button onClick={handleBack} className="p-1 hover:bg-slate-100 rounded">
                <ChevronLeft className="w-5 h-5" />
              </button>
              <h2 className="text-xl font-bold">Device Details</h2>
            </div>
            
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {deviceTypes.map((item) => (
                <button
                  key={item.type}
                  onClick={() => setFormData({ ...formData, deviceType: item.type })}
                  className={`p-4 rounded-xl border-2 flex flex-col items-center gap-2 transition-all ${
                    formData.deviceType === item.type 
                      ? 'border-blue-600 bg-blue-50 text-blue-600' 
                      : 'border-slate-200 bg-white text-slate-500 hover:border-slate-300'
                  }`}
                >
                  <item.icon className="w-6 h-6" />
                  <span className="text-xs font-bold">{item.type}</span>
                </button>
              ))}
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Model Name / Number</label>
                <input 
                  type="text" 
                  value={formData.deviceModel}
                  onChange={(e) => setFormData({ ...formData, deviceModel: e.target.value })}
                  placeholder="e.g. iPhone 14 Pro, ASUS Zephyrus"
                  className="w-full px-4 py-3 rounded-lg border border-slate-200 focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Describe the Issue</label>
                <textarea 
                  rows={3}
                  value={formData.issueDescription}
                  onChange={(e) => setFormData({ ...formData, issueDescription: e.target.value })}
                  placeholder="Tell us what's wrong with your device..."
                  className="w-full px-4 py-3 rounded-lg border border-slate-200 focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none resize-none"
                />
              </div>
              <button 
                onClick={handleNext}
                disabled={!formData.deviceModel || !formData.issueDescription}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white py-4 rounded-xl font-bold shadow-lg shadow-blue-900/20 transition-all disabled:bg-slate-300 disabled:shadow-none"
              >
                Continue
              </button>
            </div>
          </motion.div>
        )}

        {step === 3 && (
          <motion.div 
            key="step3"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="px-4 space-y-6"
          >
            <div className="flex items-center gap-2 mb-2">
              <button onClick={handleBack} className="p-1 hover:bg-slate-100 rounded">
                <ChevronLeft className="w-5 h-5" />
              </button>
              <h2 className="text-xl font-bold">Contact Information</h2>
            </div>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Full Name</label>
                <input 
                  type="text" 
                  value={formData.customerName}
                  onChange={(e) => setFormData({ ...formData, customerName: e.target.value })}
                  placeholder="Juan Dela Cruz"
                  className="w-full px-4 py-3 rounded-lg border border-slate-200 focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Contact Number</label>
                <input 
                  type="tel" 
                  value={formData.contactNumber}
                  onChange={(e) => setFormData({ ...formData, contactNumber: e.target.value })}
                  placeholder="0917 XXX XXXX"
                  className="w-full px-4 py-3 rounded-lg border border-slate-200 focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none"
                />
              </div>
              
              <div className="bg-amber-50 border border-amber-100 p-4 rounded-xl text-amber-800 text-sm">
                <p className="font-bold flex items-center gap-2 mb-1">
                  <Clock className="w-4 h-4" />
                  FIFO Notice
                </p>
                <p>Your appointment will be queued based on your arrival time at the shop. The current estimated wait time is approximately <strong>{branches.find(b => b.id === formData.branchId)?.estimatedWaitMinutes} minutes</strong>.</p>
              </div>

              <button 
                onClick={() => onComplete(formData)}
                disabled={!formData.customerName || !formData.contactNumber}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white py-4 rounded-xl font-bold shadow-lg shadow-blue-900/20 transition-all disabled:bg-slate-300 disabled:shadow-none"
              >
                Confirm Booking
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
